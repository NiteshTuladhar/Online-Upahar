from django.shortcuts import render
from .models import Banner

# Create your views here.