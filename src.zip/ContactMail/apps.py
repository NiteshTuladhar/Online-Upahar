from django.apps import AppConfig


class ContactmailConfig(AppConfig):
    name = 'ContactMail'
