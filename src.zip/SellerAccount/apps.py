from django.apps import AppConfig


class SelleraccountConfig(AppConfig):
    name = 'SellerAccount'
