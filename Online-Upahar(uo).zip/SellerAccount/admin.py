from django.contrib import admin
from .models import SellerAccount, Contact_Seller_Account

# Register your models here.
admin.site.register(SellerAccount)
admin.site.register(Contact_Seller_Account)
