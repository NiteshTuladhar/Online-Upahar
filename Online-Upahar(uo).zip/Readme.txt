Main Color codes used
#2b647c-------Darker Blue Color Used in Category in Navigation
#3d79b1-------Lighter than above, used in navigation in background


---------------------
10/09/2020----------- Profile app is added.
10/11/2020----------- ContactMail app is added